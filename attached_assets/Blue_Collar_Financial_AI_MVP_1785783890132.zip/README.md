# Blue Collar Financial AI — MVP Prototype

## What this build does
- Accepts multiple financial screenshots
- Uses Tesseract.js OCR in the browser when internet access is available
- Attempts basic extraction of balances, hourly rate, net pay, and debt balances
- Requires the user to confirm/edit extracted values
- Calculates lineman-style pay: straight time, overtime, double time, per diem, taxes, and retirement
- Tracks debts, monthly expenses, assets, emergency fund coverage, and cash flow
- Includes a basic scenario builder
- Saves the profile in the user's browser and exports JSON

## Run it
Open `index.html` in a browser. For the most reliable OCR behavior, publish it through a simple static host rather than opening it directly from Files.

Good prototype hosting:
- Netlify Drop
- Vercel
- GitHub Pages
- Cloudflare Pages

## Important limitation
This is a front-end MVP. Production-grade screenshot extraction requires a secure backend and an OCR/vision model API. The production version should:
1. Upload images through encrypted HTTPS.
2. Strip images after processing unless the user explicitly saves them.
3. Send extracted fields—not raw screenshots—to the database.
4. Use authentication and row-level security.
5. Show a confirmation screen before saving any extracted value.
6. Avoid storing full account numbers, Social Security numbers, or bank login credentials.

## Recommended production stack
- Front end: Next.js or React Native / Expo
- Database/auth: Supabase
- Image storage: temporary signed uploads
- Extraction: OpenAI vision or Google Document AI
- Payments: Stripe
- Hosting: Vercel
- Analytics: privacy-friendly event tracking
